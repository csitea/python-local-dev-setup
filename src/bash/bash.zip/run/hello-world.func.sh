#!/bin/bash

do_hello_world(){

  echo "Hello World from $PRODUCT !!!"
  echo "I am the infra-core !!! I should not be ran !!!"

  exit_code="0"
}
