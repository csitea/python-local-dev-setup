#!/bin/bash

do_set_vars_on_manjaro(){

   # add any Suse Linux specific vars settings here 
   export host_name="$(hostname -s)"
}
