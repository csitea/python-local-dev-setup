#!/bin/bash

do_ubuntu_install_bins(){
	sudo apt-get install -y \
		"$@"
}
