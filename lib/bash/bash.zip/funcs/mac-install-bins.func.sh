#!/bin/bash

do_mac_install_bins(){
	brew install \
		"$@"
}
