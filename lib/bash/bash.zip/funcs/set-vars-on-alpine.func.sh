#!/bin/bash

do_set_vars_on_ubuntu(){

   # add any ubuntu specific vars settings here 
   export host_name=$(hostname -s)
}
